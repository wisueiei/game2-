// Rebuild the standalone CH00/CH01 page. Never writes the old game or story.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const story=read('story.md').replace(/\r/g,''),heads=[...story.matchAll(/^#{3,5} (.+)$/gm)],sections={};
for(let i=0;i<heads.length;i++){
 const title=heads[i][1],id=title.match(/^(10\.[\dAB.]+|ฉาก \d+)/)?.[1];if(!id)continue;
 const text=story.slice(heads[i].index,heads[i+1]?.index||story.length);
 sections[id]={title,blocks:[...text.matchAll(/```(?:text)?\n([\s\S]*?)```/g)].map(m=>m[1].replace(/\n$/,'').split('\n').map(x=>x.replace(/^\* /,'')))};
}
const dispatch={};
for(const m of story.matchAll(/\*\*(D(?:00|01)-[A-Z-]+):\*\* “([^”]+)”/g))dispatch[m[1]]=[m[2]];
for(const m of story.matchAll(/^\*\*(D(?:00|01)-[A-Z-]+)[^\n]*\n/gm)){
 const tail=story.slice(m.index+m[0].length),stop=tail.search(/^(?:\*\*D|#{3,5} )/m),part=stop<0?tail:tail.slice(0,stop);
 const blocks=[...part.matchAll(/```(?:text)?\n([\s\S]*?)```/g)].flatMap(b=>b[1].replace(/\n$/,'').split('\n'));if(blocks.length)dispatch[m[1]]=blocks;
}
const encounters={};
for(const m of story.matchAll(/^##### (E01-[A-Z]+) · ([^\n]+)\n([\s\S]*?)(?=^##### |^#### |^---|$(?![\s\S]))/gm)){
 const t=m[3];encounters[m[1]]={steps:[...t.matchAll(/^\d+\. “([^”]+)”/gm)].map(q=>q[1]),intro:t.match(/พบ: “([^”]+)”/)?.[1],hurt:t.match(/(?:แทน:|บทปล่อย:|ตีแต่ปล่อย:|เคยทำร้าย[^\n]*?:) “([^”]+)”/)?.[1],act:[...t.matchAll(/ACT[^\n]*?: “([^”]+)”/g)].map(q=>q[1]),allQuotes:[...t.matchAll(/“([^”]+)”/g)].map(q=>q[1])};
}
const glyphs=[...story.slice(story.indexOf('#### 10.1 ·'),story.indexOf('#### 10.2 ·')).matchAll(/^\| [1-7] \| (.+?) \| (.+?) \|$/gm)].map(m=>[m[1],m[2]]);
const inlineFile=f=>{const data=fs.readFileSync(path.join(root,f));return 'data:image/png;base64,'+data.toString('base64');};
const manifest=JSON.parse(read('assets/characters/player-r5/v1/manifest.json')),images={};
for(const [id,frame]of Object.entries(manifest.frames))images[id]=inlineFile('assets/characters/player-r5/v1/'+frame.file);
images.ruins=inlineFile('design/monsters/2026-10-08-revision-02/04-ruins-monsters-r2.png');
images.toriel=inlineFile('design/monsters/2026-10-08-revision-02/01-main-cast-r2.png');
images.faces=inlineFile('design/dialogue-portraits/2026-10-08-v1/01-core-cast-dialogue-faces-v1.png');
images.ruinsFaces=inlineFile('design/dialogue-portraits/2026-10-08-v1/05-ruins-encounter-dialogue-faces-v1.png');
images.neighborFaces=inlineFile('design/dialogue-portraits/2026-10-08-v1/06-ruins-rest-and-neighbors-faces-v1.png');
images.stat=inlineFile('assets/characters/player-stat/v1/player-stat-star-64x112.png');
const data={sections,dispatch,encounters,glyphs,layout:JSON.parse(read('design/chapters/current-layout.json')),manifest,images,sourceHash:crypto.createHash('sha256').update(story).digest('hex')};
const html=read('tools/index-new-shell.html').replace('/*__STYLE__*/',read('tools/index-new.css')).replace('/*__DATA__*/','const CONTENT='+JSON.stringify(data).replace(/</g,'\\u003c')+';').replace('/*__ENGINE__*/',read('tools/index-new-engine.js'));
fs.writeFileSync(path.join(root,'index_new.html'),html,'utf8');
console.log(JSON.stringify({file:'index_new.html',bytes:Buffer.byteLength(html),sections:Object.keys(sections).length,dialogueIds:Object.keys(dispatch).length,encounters:Object.fromEntries(Object.entries(encounters).map(([k,v])=>[k,v.steps.length]))}));
