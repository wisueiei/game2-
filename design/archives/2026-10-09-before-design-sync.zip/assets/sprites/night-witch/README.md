# Night Witch — 24×32 sprite frames

Each file is a separate 24×32 RGBA PNG with a transparent background. The frames use a shared 16-colour opaque palette, hard 1:1 pixels, and a dark `#0A1022` outline.

| Direction | Idle | Walk |
| --- | --- | --- |
| Front | `night-witch-front-idle-24x32.png` | `night-witch-front-walk-24x32.png` |
| Back | `night-witch-back-idle-24x32.png` | `night-witch-back-walk-24x32.png` |
| Left | `night-witch-left-idle-24x32.png` | `night-witch-left-walk-24x32.png` |
| Right | `night-witch-right-idle-24x32.png` | `night-witch-right-walk-24x32.png` |

The walk frames extend one leg forward. Keep nearest-neighbor scaling enabled in the game engine.
